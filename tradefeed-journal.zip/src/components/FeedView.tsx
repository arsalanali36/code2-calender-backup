import React from 'react';
import { FeedCard } from './FeedCard';
import { Filter, Search } from 'lucide-react';
import { Trade } from '../types';

interface FeedViewProps {
  trades: Trade[];
}

export const FeedView: React.FC<FeedViewProps> = ({ trades }) => {
  return (
    <div className="max-w-md mx-auto pb-24 pt-6 px-4">
      {/* Feed Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-zinc-900 tracking-tight">Trade Feed</h1>
          <p className="text-xs text-zinc-500">Review your recent performance</p>
        </div>
        <div className="flex gap-2">
          <button className="p-2 bg-zinc-100 rounded-full text-zinc-600 hover:bg-zinc-200 transition-colors">
            <Search className="w-5 h-5" />
          </button>
          <button className="p-2 bg-zinc-100 rounded-full text-zinc-600 hover:bg-zinc-200 transition-colors">
            <Filter className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Stories-like daily summary */}
      <div className="flex gap-4 overflow-x-auto pb-6 no-scrollbar">
        {['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].map((day, i) => (
          <div key={day} className="flex flex-col items-center gap-1 flex-shrink-0">
            <div className={`w-14 h-14 rounded-full p-0.5 border-2 ${i === 4 ? 'border-indigo-500' : 'border-zinc-200'}`}>
              <div className="w-full h-full rounded-full bg-zinc-50 flex items-center justify-center text-[10px] font-bold text-zinc-800 border border-zinc-100">
                {day}
              </div>
            </div>
            <span className="text-[10px] text-zinc-500 font-medium">{i === 4 ? 'Today' : `Mar ${2+i}`}</span>
          </div>
        ))}
      </div>

      {/* Feed List */}
      <div className="space-y-2">
        {trades.map(trade => (
          <FeedCard key={trade.id} trade={trade} />
        ))}
      </div>
    </div>
  );
};
