/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { FeedView } from './components/FeedView';
import { BottomNav } from './components/BottomNav';
import { ViewType, Trade } from './types';
import { motion, AnimatePresence } from 'motion/react';
import { PlusSquare, Grid3X3 } from 'lucide-react';
import { mockTrades as initialMockTrades } from './data/mockTrades';
import { ImageImport } from './components/ImageImport';
import { Tagger } from './components/Tagger';
import { TradeLogger } from './components/TradeLogger';

// Placeholder components for existing modules with improved light-themed mockups
const CalendarView = () => (
  <div className="max-w-md mx-auto p-6 pb-24">
    <div className="flex items-center justify-between mb-6">
      <h1 className="text-2xl font-bold text-zinc-900">Day Stats</h1>
      <div className="bg-emerald-50 text-emerald-600 px-3 py-1 rounded-full text-xs font-bold border border-emerald-100">
        +₹5,132.50
      </div>
    </div>
    <div className="grid grid-cols-7 gap-1 mb-6">
      {Array.from({ length: 31 }).map((_, i) => (
        <div key={i} className={`aspect-square rounded-lg flex items-center justify-center text-[10px] font-bold ${
          i === 1 ? 'bg-emerald-500 text-white' : 
          i === 5 ? 'bg-rose-500 text-white' : 
          'bg-zinc-50 text-zinc-400 border border-zinc-100'
        }`}>
          {i + 1}
        </div>
      ))}
    </div>
    <div className="space-y-4">
      <div className="bg-white p-4 rounded-xl border border-zinc-200 shadow-sm">
        <h3 className="text-sm font-bold text-zinc-800 mb-3">Daily Performance</h3>
        <div className="space-y-2">
          <div className="flex justify-between text-xs">
            <span className="text-zinc-500">Gross P&L</span>
            <span className="text-emerald-600 font-bold">+₹5,400.00</span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-zinc-500">Charges</span>
            <span className="text-rose-600 font-bold">-₹267.50</span>
          </div>
          <div className="h-px bg-zinc-100 my-2" />
          <div className="flex justify-between text-sm font-bold">
            <span className="text-zinc-900">Net P&L</span>
            <span className="text-emerald-600">+₹5,132.50</span>
          </div>
        </div>
      </div>
    </div>
  </div>
);

const DashboardView = () => (
  <div className="max-w-md mx-auto p-6 pb-24">
    <h1 className="text-2xl font-bold text-zinc-900 mb-6">Performance</h1>
    <div className="bg-white p-4 rounded-xl border border-zinc-200 shadow-sm mb-6">
      <div className="flex items-center justify-between mb-4">
        <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider">Equity Curve</span>
        <span className="text-xs text-indigo-600 font-bold">Monthly</span>
      </div>
      <div className="h-32 flex items-end gap-1">
        {[40, 45, 38, 52, 60, 58, 70, 75, 72, 85].map((h, i) => (
          <div key={i} className="flex-1 bg-indigo-500/20 rounded-t-sm relative group">
            <div 
              className="absolute bottom-0 left-0 right-0 bg-indigo-500 rounded-t-sm transition-all group-hover:bg-indigo-600" 
              style={{ height: `${h}%` }} 
            />
          </div>
        ))}
      </div>
    </div>
    <div className="grid grid-cols-2 gap-4">
      <div className="bg-white p-4 rounded-xl border border-zinc-200 shadow-sm">
        <span className="text-[10px] font-bold text-zinc-400 uppercase">Win Rate</span>
        <p className="text-xl font-bold text-zinc-900">64.2%</p>
      </div>
      <div className="bg-white p-4 rounded-xl border border-zinc-200 shadow-sm">
        <span className="text-[10px] font-bold text-zinc-400 uppercase">Profit Factor</span>
        <p className="text-xl font-bold text-zinc-900">2.14</p>
      </div>
    </div>
  </div>
);

const TableView = ({ trades, onLogTrade }: { trades: Trade[], onLogTrade: () => void }) => (
  <div className="max-w-md mx-auto p-6 pb-24">
    <div className="flex items-center justify-between mb-6">
      <h1 className="text-2xl font-bold text-zinc-900">Trade History</h1>
      <button 
        onClick={onLogTrade}
        className="p-2 bg-zinc-900 text-white rounded-full shadow-lg hover:bg-zinc-800 transition-all active:scale-95"
      >
        <PlusSquare className="w-5 h-5" />
      </button>
    </div>
    <div className="bg-white rounded-xl border border-zinc-200 shadow-sm overflow-hidden">
      <table className="w-full text-left text-xs">
        <thead className="bg-zinc-50 border-b border-zinc-200">
          <tr>
            <th className="p-3 font-bold text-zinc-500 uppercase">Instrument</th>
            <th className="p-3 font-bold text-zinc-500 uppercase text-right">P&L</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-zinc-100">
          {trades.map(trade => (
            <tr key={trade.id}>
              <td className="p-3">
                <p className="font-bold text-zinc-900">{trade.instrument}</p>
                <p className="text-[10px] text-zinc-400">{trade.date}</p>
              </td>
              <td className={`p-3 text-right font-bold ${trade.pnl >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                {trade.pnl >= 0 ? '+' : ''}₹{Math.abs(trade.pnl).toLocaleString()}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
);

const GalleryView = ({ trades }: { trades: Trade[] }) => {
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [galleryMode, setGalleryMode] = useState<'tags' | 'day'>('tags');
  
  // Extract all unique tags
  const allTags = Array.from(new Set([
    ...trades.flatMap(t => t.emotionTags),
    ...trades.flatMap(t => t.strategyTags),
    ...trades.flatMap(t => t.mistakeTags)
  ])).sort();

  const filteredTrades = trades.filter(t => 
    !selectedTag || 
    t.emotionTags.includes(selectedTag) || 
    t.strategyTags.includes(selectedTag) || 
    t.mistakeTags.includes(selectedTag)
  );

  const filteredImages = filteredTrades
    .flatMap(t => t.chartUrls.map(url => ({ 
      url, 
      tradeId: t.id, 
      tag: t.strategyTags[0] || t.emotionTags[0] || t.mistakeTags[0] || '' 
    })));

  // Group by day logic
  const groupedByDay = trades.reduce((acc, trade) => {
    const date = trade.date;
    if (!acc[date]) acc[date] = [];
    trade.chartUrls.forEach(url => {
      acc[date].push({ url, tradeId: trade.id, tag: trade.strategyTags[0] || trade.emotionTags[0] || '' });
    });
    return acc;
  }, {} as Record<string, { url: string, tradeId: string, tag: string }[]>);

  const sortedDates = Object.keys(groupedByDay).sort((a, b) => new Date(b).getTime() - new Date(a).getTime());

  return (
    <div className="max-w-md mx-auto p-6 pb-24">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold text-zinc-900">Chart Gallery</h1>
        <button 
          onClick={() => setGalleryMode(galleryMode === 'tags' ? 'day' : 'tags')}
          className="text-xs font-bold text-indigo-600 hover:text-indigo-700 transition-colors"
        >
          {galleryMode === 'tags' ? 'Day view' : 'Tags view'}
        </button>
      </div>
      
      {galleryMode === 'tags' ? (
        <>
          {/* Tag Filter Bar */}
          <div className="flex gap-2 overflow-x-auto pb-4 no-scrollbar -mx-6 px-6">
            <button
              onClick={() => setSelectedTag(null)}
              className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all ${
                !selectedTag ? 'bg-zinc-900 text-white' : 'bg-zinc-100 text-zinc-500 hover:bg-zinc-200'
              }`}
            >
              All Charts
            </button>
            {allTags.map(tag => (
              <button
                key={tag}
                onClick={() => setSelectedTag(tag)}
                className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all ${
                  selectedTag === tag ? 'bg-indigo-600 text-white' : 'bg-zinc-100 text-zinc-500 hover:bg-zinc-200'
                }`}
              >
                {tag}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-3 gap-1">
            {filteredImages.map((img, i) => (
              <div key={`${img.tradeId}-${i}`} className="aspect-square bg-zinc-100 overflow-hidden group cursor-pointer relative">
                <img 
                  src={img.url} 
                  alt="Gallery" 
                  className="w-full h-full object-cover transition-transform group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
                {img.tag && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/10 group-hover:bg-black/20 transition-colors">
                    <span className="text-[10px] font-black text-white uppercase tracking-widest drop-shadow-md transform -rotate-12 select-none pointer-events-none">
                      {img.tag}
                    </span>
                  </div>
                )}
              </div>
            ))}
          </div>
          {filteredImages.length === 0 && (
            <div className="flex flex-col items-center justify-center py-20 text-zinc-400">
              <Grid3X3 className="w-12 h-12 mb-2 opacity-20" />
              <p className="text-sm">No charts found for this tag</p>
            </div>
          )}
        </>
      ) : (
        <div className="space-y-8">
          {sortedDates.map(date => (
            <div key={date}>
              <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                <div className="h-px flex-1 bg-zinc-100" />
                {new Date(date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                <div className="h-px flex-1 bg-zinc-100" />
              </h3>
              <div className="grid grid-cols-3 gap-1">
                {groupedByDay[date].map((img, i) => (
                  <div key={`${img.tradeId}-${i}`} className="aspect-square bg-zinc-100 overflow-hidden group cursor-pointer relative">
                    <img 
                      src={img.url} 
                      alt="Gallery" 
                      className="w-full h-full object-cover transition-transform group-hover:scale-110"
                      referrerPolicy="no-referrer"
                    />
                    {img.tag && (
                      <div className="absolute inset-0 flex items-center justify-center bg-black/10 group-hover:bg-black/20 transition-colors">
                        <span className="text-[10px] font-black text-white uppercase tracking-widest drop-shadow-md transform -rotate-12 select-none pointer-events-none">
                          {img.tag}
                        </span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default function App() {
  const [currentView, setCurrentView] = useState<ViewType>('feed');
  const [trades, setTrades] = useState<Trade[]>(initialMockTrades);
  
  // Creation Flow State
  const [creationImages, setCreationImages] = useState<string[]>([]);
  const [creationTags, setCreationTags] = useState<{ emotion: string[], strategy: string[], mistake: string[] }>({ emotion: [], strategy: [], mistake: [] });

  const handleSaveTrade = (tradeData: Partial<Trade>) => {
    const newTrade: Trade = {
      id: Math.random().toString(36).substr(2, 9),
      instrument: tradeData.instrument || 'Unknown',
      pnl: tradeData.pnl || 0,
      type: tradeData.type || 'Long',
      session: tradeData.session || 'Morning',
      date: tradeData.date || new Date().toISOString().split('T')[0],
      chartUrls: tradeData.chartUrls || [],
      emotionTags: tradeData.emotionTags || [],
      strategyTags: tradeData.strategyTags || [],
      mistakeTags: tradeData.mistakeTags || [],
      note: tradeData.note || '',
      stats: tradeData.stats || { rMultiple: 0, riskReward: '1:1', positionSize: 0 },
      currency: '₹'
    };
    
    setTrades([newTrade, ...trades]);
    setCurrentView('feed');
    // Reset flow
    setCreationImages([]);
    setCreationTags({ emotion: [], strategy: [], mistake: [] });
  };

  const renderView = () => {
    switch (currentView) {
      case 'feed':
        return <FeedView trades={trades} />;
      case 'calendar':
        return <CalendarView />;
      case 'dashboard':
        return <DashboardView />;
      case 'table':
        return <TableView trades={trades} onLogTrade={() => setCurrentView('import')} />;
      case 'gallery':
        return <GalleryView trades={trades} />;
      case 'import':
        return (
          <ImageImport 
            onNext={(images) => {
              setCreationImages(images);
              setCurrentView('tagger');
            }}
            onCancel={() => setCurrentView('feed')}
          />
        );
      case 'tagger':
        return (
          <Tagger 
            images={creationImages}
            onNext={(tags) => {
              setCreationTags(tags);
              setCurrentView('logger');
            }}
            onBack={() => setCurrentView('import')}
          />
        );
      case 'logger':
        return (
          <TradeLogger 
            images={creationImages}
            tags={creationTags}
            onSave={handleSaveTrade}
            onBack={() => setCurrentView('tagger')}
          />
        );
      default:
        return <FeedView trades={trades} />;
    }
  };

  return (
    <div className="min-h-screen bg-white text-zinc-900 font-sans selection:bg-indigo-100 selection:text-indigo-900">
      {/* Main Content Area */}
      <main className="relative z-10">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentView}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {renderView()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Persistent Bottom Navigation */}
      <BottomNav currentView={currentView} onViewChange={setCurrentView} />

      {/* Decorative Background Elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden -z-10">
        <div className="absolute -top-[10%] -left-[10%] w-[40%] h-[40%] bg-indigo-500/10 blur-[120px] rounded-full" />
        <div className="absolute -bottom-[10%] -right-[10%] w-[40%] h-[40%] bg-emerald-500/5 blur-[120px] rounded-full" />
      </div>
    </div>
  );
}
